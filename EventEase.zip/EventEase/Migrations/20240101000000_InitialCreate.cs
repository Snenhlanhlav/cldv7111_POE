using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814

namespace EventEase.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // ── EventTypes ──────────────────────────────────────────────────
            migrationBuilder.CreateTable(
                name: "EventTypes",
                columns: table => new
                {
                    EventTypeId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TypeName = table.Column<string>(maxLength: 100, nullable: false)
                },
                constraints: table => table.PrimaryKey("PK_EventTypes", x => x.EventTypeId));

            migrationBuilder.InsertData("EventTypes", new[] { "EventTypeId", "TypeName" }, new object[,]
            {
                { 1,  "Conference"         },
                { 2,  "Wedding"            },
                { 3,  "Concert"            },
                { 4,  "Corporate Function" },
                { 5,  "Birthday Party"     },
                { 6,  "Exhibition"         },
                { 7,  "Workshop"           },
                { 8,  "Gala Dinner"        },
                { 9,  "Sports Event"       },
                { 10, "Other"              }
            });

            // ── Venues ──────────────────────────────────────────────────────
            migrationBuilder.CreateTable(
                name: "Venues",
                columns: table => new
                {
                    VenueId     = table.Column<int>(nullable: false).Annotation("SqlServer:Identity", "1, 1"),
                    VenueName   = table.Column<string>(maxLength: 150, nullable: false),
                    Location    = table.Column<string>(maxLength: 250, nullable: false),
                    Capacity    = table.Column<int>(nullable: false),
                    ImageUrl    = table.Column<string>(maxLength: 500, nullable: true),
                    IsAvailable = table.Column<bool>(nullable: false, defaultValue: true)
                },
                constraints: table => table.PrimaryKey("PK_Venues", x => x.VenueId));

            // ── Events ───────────────────────────────────────────────────────
            migrationBuilder.CreateTable(
                name: "Events",
                columns: table => new
                {
                    EventId     = table.Column<int>(nullable: false).Annotation("SqlServer:Identity", "1, 1"),
                    EventName   = table.Column<string>(maxLength: 150, nullable: false),
                    EventDate   = table.Column<DateTime>(nullable: false),
                    EndDate     = table.Column<DateTime>(nullable: true),
                    Description = table.Column<string>(maxLength: 1000, nullable: true),
                    ImageUrl    = table.Column<string>(maxLength: 500, nullable: true),
                    VenueId     = table.Column<int>(nullable: true),
                    EventTypeId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Events", x => x.EventId);
                    table.ForeignKey("FK_Events_Venues_VenueId",    x => x.VenueId,    "Venues",     "VenueId",     onDelete: ReferentialAction.SetNull);
                    table.ForeignKey("FK_Events_EventTypes_TypeId",  x => x.EventTypeId,"EventTypes", "EventTypeId", onDelete: ReferentialAction.SetNull);
                });

            // ── Bookings ─────────────────────────────────────────────────────
            migrationBuilder.CreateTable(
                name: "Bookings",
                columns: table => new
                {
                    BookingId   = table.Column<int>(nullable: false).Annotation("SqlServer:Identity", "1, 1"),
                    EventId     = table.Column<int>(nullable: false),
                    VenueId     = table.Column<int>(nullable: false),
                    BookingDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Bookings", x => x.BookingId);
                    table.ForeignKey("FK_Bookings_Events_EventId",   x => x.EventId,  "Events", "EventId",  onDelete: ReferentialAction.Restrict);
                    table.ForeignKey("FK_Bookings_Venues_VenueId",   x => x.VenueId,  "Venues", "VenueId",  onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex("IX_Bookings_VenueId_EventId", "Bookings", new[] { "VenueId", "EventId" }, unique: true);
            migrationBuilder.CreateIndex("IX_Events_VenueId",     "Events",   "VenueId");
            migrationBuilder.CreateIndex("IX_Events_EventTypeId", "Events",   "EventTypeId");
            migrationBuilder.CreateIndex("IX_Bookings_EventId",   "Bookings", "EventId");

            // ── vw_BookingDetails view ────────────────────────────────────────
            migrationBuilder.Sql(@"
CREATE OR ALTER VIEW vw_BookingDetails AS
SELECT
    b.BookingId,
    b.BookingDate,
    e.EventName,
    e.EventDate,
    e.EndDate,
    e.Description   AS EventDescription,
    e.ImageUrl      AS EventImageUrl,
    et.TypeName     AS EventTypeName,
    v.VenueName,
    v.Location,
    v.Capacity,
    v.ImageUrl      AS VenueImageUrl
FROM Bookings b
INNER JOIN Events  e  ON b.EventId     = e.EventId
INNER JOIN Venues  v  ON b.VenueId     = v.VenueId
LEFT  JOIN EventTypes et ON e.EventTypeId = et.EventTypeId;
");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DROP VIEW IF EXISTS vw_BookingDetails");
            migrationBuilder.DropTable("Bookings");
            migrationBuilder.DropTable("Events");
            migrationBuilder.DropTable("Venues");
            migrationBuilder.DropTable("EventTypes");
        }
    }
}
