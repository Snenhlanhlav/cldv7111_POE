using EventEase.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;

namespace EventEase.Migrations
{
    [DbContext(typeof(ApplicationDbContext))]
    partial class ApplicationDbContextModelSnapshot : ModelSnapshot
    {
        protected override void BuildModel(ModelBuilder modelBuilder)
        {
#pragma warning disable 612, 618
            modelBuilder.HasAnnotation("ProductVersion", "8.0.0")
                        .HasAnnotation("Relational:MaxIdentifierLength", 128);

            modelBuilder.Entity("EventEase.Models.EventType", b =>
            {
                b.Property<int>("EventTypeId").ValueGeneratedOnAdd()
                    .HasColumnType("int")
                    .UseIdentityColumn();
                b.Property<string>("TypeName").IsRequired().HasMaxLength(100);
                b.HasKey("EventTypeId");
                b.ToTable("EventTypes");
                b.HasData(
                    new { EventTypeId = 1,  TypeName = "Conference"         },
                    new { EventTypeId = 2,  TypeName = "Wedding"            },
                    new { EventTypeId = 3,  TypeName = "Concert"            },
                    new { EventTypeId = 4,  TypeName = "Corporate Function" },
                    new { EventTypeId = 5,  TypeName = "Birthday Party"     },
                    new { EventTypeId = 6,  TypeName = "Exhibition"         },
                    new { EventTypeId = 7,  TypeName = "Workshop"           },
                    new { EventTypeId = 8,  TypeName = "Gala Dinner"        },
                    new { EventTypeId = 9,  TypeName = "Sports Event"       },
                    new { EventTypeId = 10, TypeName = "Other"              }
                );
            });

            modelBuilder.Entity("EventEase.Models.Venue", b =>
            {
                b.Property<int>("VenueId").ValueGeneratedOnAdd().HasColumnType("int").UseIdentityColumn();
                b.Property<string>("VenueName").IsRequired().HasMaxLength(150);
                b.Property<string>("Location").IsRequired().HasMaxLength(250);
                b.Property<int>("Capacity").HasColumnType("int");
                b.Property<string?>("ImageUrl").HasMaxLength(500);
                b.Property<bool>("IsAvailable").HasColumnType("bit");
                b.HasKey("VenueId");
                b.ToTable("Venues");
            });

            modelBuilder.Entity("EventEase.Models.Event", b =>
            {
                b.Property<int>("EventId").ValueGeneratedOnAdd().HasColumnType("int").UseIdentityColumn();
                b.Property<string>("EventName").IsRequired().HasMaxLength(150);
                b.Property<DateTime>("EventDate").HasColumnType("datetime2");
                b.Property<DateTime?>("EndDate").HasColumnType("datetime2");
                b.Property<string?>("Description").HasMaxLength(1000);
                b.Property<string?>("ImageUrl").HasMaxLength(500);
                b.Property<int?>("VenueId").HasColumnType("int");
                b.Property<int?>("EventTypeId").HasColumnType("int");
                b.HasKey("EventId");
                b.HasIndex("VenueId");
                b.HasIndex("EventTypeId");
                b.ToTable("Events");
            });

            modelBuilder.Entity("EventEase.Models.Booking", b =>
            {
                b.Property<int>("BookingId").ValueGeneratedOnAdd().HasColumnType("int").UseIdentityColumn();
                b.Property<int>("EventId").HasColumnType("int");
                b.Property<int>("VenueId").HasColumnType("int");
                b.Property<DateTime>("BookingDate").HasColumnType("datetime2");
                b.HasKey("BookingId");
                b.HasIndex(new[] { "VenueId", "EventId" }, name: "IX_Bookings_VenueId_EventId").IsUnique();
                b.ToTable("Bookings");
            });

            modelBuilder.Entity("EventEase.Models.BookingDetail", b =>
            {
                b.HasNoKey();
                b.ToView("vw_BookingDetails");
                b.Property<int>("BookingId");
                b.Property<DateTime>("BookingDate");
                b.Property<string>("EventName").IsRequired();
                b.Property<DateTime>("EventDate");
                b.Property<DateTime?>("EndDate");
                b.Property<string?>("EventDescription");
                b.Property<string?>("EventTypeName");
                b.Property<string>("VenueName").IsRequired();
                b.Property<string>("Location").IsRequired();
                b.Property<int>("Capacity");
                b.Property<string?>("VenueImageUrl");
                b.Property<string?>("EventImageUrl");
            });

            // Relationships
            modelBuilder.Entity("EventEase.Models.Event", b =>
            {
                b.HasOne("EventEase.Models.Venue", "Venue")
                    .WithMany("Events").HasForeignKey("VenueId")
                    .OnDelete(DeleteBehavior.SetNull);
                b.HasOne("EventEase.Models.EventType", "EventType")
                    .WithMany("Events").HasForeignKey("EventTypeId")
                    .OnDelete(DeleteBehavior.SetNull);
            });

            modelBuilder.Entity("EventEase.Models.Booking", b =>
            {
                b.HasOne("EventEase.Models.Event", "Event")
                    .WithMany("Bookings").HasForeignKey("EventId")
                    .OnDelete(DeleteBehavior.Restrict).IsRequired();
                b.HasOne("EventEase.Models.Venue", "Venue")
                    .WithMany("Bookings").HasForeignKey("VenueId")
                    .OnDelete(DeleteBehavior.Restrict).IsRequired();
            });
#pragma warning restore 612, 618
        }
    }
}
