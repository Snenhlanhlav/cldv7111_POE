using Microsoft.EntityFrameworkCore;
using EventEase.Models;

namespace EventEase.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) { }

        public DbSet<Venue> Venues { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<Booking> Bookings { get; set; }
        public DbSet<EventType> EventTypes { get; set; }

        // Keyless entity for the database view
        public DbSet<BookingDetail> BookingDetails { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // ── Venue ──────────────────────────────────────────────────────────
            modelBuilder.Entity<Venue>(entity =>
            {
                entity.HasKey(v => v.VenueId);
                entity.Property(v => v.VenueName).IsRequired().HasMaxLength(150);
                entity.Property(v => v.Location).IsRequired().HasMaxLength(250);
                entity.Property(v => v.ImageUrl).HasMaxLength(500);
            });

            // ── EventType ──────────────────────────────────────────────────────
            modelBuilder.Entity<EventType>(entity =>
            {
                entity.HasKey(et => et.EventTypeId);
                entity.Property(et => et.TypeName).IsRequired().HasMaxLength(100);

                // Seed predefined categories
                entity.HasData(
                    new EventType { EventTypeId = 1, TypeName = "Conference" },
                    new EventType { EventTypeId = 2, TypeName = "Wedding" },
                    new EventType { EventTypeId = 3, TypeName = "Concert" },
                    new EventType { EventTypeId = 4, TypeName = "Corporate Function" },
                    new EventType { EventTypeId = 5, TypeName = "Birthday Party" },
                    new EventType { EventTypeId = 6, TypeName = "Exhibition" },
                    new EventType { EventTypeId = 7, TypeName = "Workshop" },
                    new EventType { EventTypeId = 8, TypeName = "Gala Dinner" },
                    new EventType { EventTypeId = 9, TypeName = "Sports Event" },
                    new EventType { EventTypeId = 10, TypeName = "Other" }
                );
            });

            // ── Event ──────────────────────────────────────────────────────────
            modelBuilder.Entity<Event>(entity =>
            {
                entity.HasKey(e => e.EventId);
                entity.Property(e => e.EventName).IsRequired().HasMaxLength(150);
                entity.Property(e => e.Description).HasMaxLength(1000);
                entity.Property(e => e.ImageUrl).HasMaxLength(500);

                entity.HasOne(e => e.Venue)
                      .WithMany(v => v.Events)
                      .HasForeignKey(e => e.VenueId)
                      .OnDelete(DeleteBehavior.SetNull);

                entity.HasOne(e => e.EventType)
                      .WithMany(et => et.Events)
                      .HasForeignKey(e => e.EventTypeId)
                      .OnDelete(DeleteBehavior.SetNull);
            });

            // ── Booking ────────────────────────────────────────────────────────
            modelBuilder.Entity<Booking>(entity =>
            {
                entity.HasKey(b => b.BookingId);

                entity.HasOne(b => b.Event)
                      .WithMany(e => e.Bookings)
                      .HasForeignKey(b => b.EventId)
                      .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(b => b.Venue)
                      .WithMany(v => v.Bookings)
                      .HasForeignKey(b => b.VenueId)
                      .OnDelete(DeleteBehavior.Restrict);

                // Prevent double-booking: unique constraint on VenueId + EventDate
                entity.HasIndex(b => new { b.VenueId, b.EventId }).IsUnique();
            });

            // ── BookingDetail (keyless — maps to DB view) ──────────────────────
            modelBuilder.Entity<BookingDetail>(entity =>
            {
                entity.HasNoKey();
                entity.ToView("vw_BookingDetails");
            });
        }
    }
}
