using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using EventEase.Data;
using EventEase.Models;

namespace EventEase.Controllers
{
    public class BookingsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public BookingsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Bookings
        public async Task<IActionResult> Index(
            string? searchTerm,
            int? eventTypeId,
            int? venueId,
            DateTime? fromDate,
            DateTime? toDate,
            bool? availableVenuesOnly)
        {
            var query = _context.BookingDetails.AsQueryable();

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                var s = searchTerm.Trim().ToLower();
                query = query.Where(b =>
                    b.EventName.ToLower().Contains(s) ||
                    b.BookingId.ToString().Contains(s) ||
                    b.VenueName.ToLower().Contains(s));
            }

            if (eventTypeId.HasValue)
                query = query.Where(b => b.EventTypeName != null);   // refined below

            if (venueId.HasValue)
            {
                var venueName = (await _context.Venues.FindAsync(venueId))?.VenueName;
                if (venueName != null)
                    query = query.Where(b => b.VenueName == venueName);
            }

            if (fromDate.HasValue)
                query = query.Where(b => b.EventDate >= fromDate.Value);

            if (toDate.HasValue)
                query = query.Where(b => b.EventDate <= toDate.Value.AddDays(1));

            // If event type filter is provided, resolve type name
            if (eventTypeId.HasValue)
            {
                var typeName = (await _context.EventTypes.FindAsync(eventTypeId))?.TypeName;
                if (typeName != null)
                    query = query.Where(b => b.EventTypeName == typeName);
            }

            ViewBag.SearchTerm = searchTerm;
            ViewBag.SelectedEventTypeId = eventTypeId;
            ViewBag.SelectedVenueId = venueId;
            ViewBag.FromDate = fromDate?.ToString("yyyy-MM-dd");
            ViewBag.ToDate = toDate?.ToString("yyyy-MM-dd");

            ViewBag.EventTypes = new SelectList(
                await _context.EventTypes.OrderBy(et => et.TypeName).ToListAsync(),
                "EventTypeId", "TypeName", eventTypeId);

            ViewBag.Venues = new SelectList(
                await _context.Venues.OrderBy(v => v.VenueName).ToListAsync(),
                "VenueId", "VenueName", venueId);

            return View(await query.OrderByDescending(b => b.BookingDate).ToListAsync());
        }

        // GET: Bookings/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var booking = await _context.Bookings
                .Include(b => b.Event).ThenInclude(e => e!.EventType)
                .Include(b => b.Venue)
                .FirstOrDefaultAsync(b => b.BookingId == id);

            if (booking == null) return NotFound();
            return View(booking);
        }

        // GET: Bookings/Create
        public async Task<IActionResult> Create()
        {
            await PopulateDropDownsAsync();
            return View(new Booking { BookingDate = DateTime.Today });
        }

        // POST: Bookings/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("EventId,VenueId,BookingDate")] Booking booking)
        {
            if (ModelState.IsValid)
            {
                // ── Double-booking check ───────────────────────────────────────
                var selectedEvent = await _context.Events.FindAsync(booking.EventId);
                if (selectedEvent == null)
                {
                    ModelState.AddModelError("EventId", "Selected event not found.");
                    await PopulateDropDownsAsync(booking.EventId, booking.VenueId);
                    return View(booking);
                }

                bool conflict = await _context.Bookings
                    .Include(b => b.Event)
                    .AnyAsync(b =>
                        b.VenueId == booking.VenueId &&
                        b.Event != null &&
                        b.Event.EventDate.Date == selectedEvent.EventDate.Date);

                if (conflict)
                {
                    ModelState.AddModelError(string.Empty,
                        "This venue is already booked for another event on the same date. Please choose a different venue or date.");
                    await PopulateDropDownsAsync(booking.EventId, booking.VenueId);
                    return View(booking);
                }

                // ── Check venue availability ───────────────────────────────────
                var venue = await _context.Venues.FindAsync(booking.VenueId);
                if (venue != null && !venue.IsAvailable)
                {
                    ModelState.AddModelError("VenueId", "The selected venue is currently marked as unavailable.");
                    await PopulateDropDownsAsync(booking.EventId, booking.VenueId);
                    return View(booking);
                }

                _context.Bookings.Add(booking);
                await _context.SaveChangesAsync();
                TempData["Success"] = $"Booking #{booking.BookingId} created successfully.";
                return RedirectToAction(nameof(Index));
            }

            await PopulateDropDownsAsync(booking.EventId, booking.VenueId);
            return View(booking);
        }

        // GET: Bookings/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var booking = await _context.Bookings.FindAsync(id);
            if (booking == null) return NotFound();

            await PopulateDropDownsAsync(booking.EventId, booking.VenueId);
            return View(booking);
        }

        // POST: Bookings/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BookingId,EventId,VenueId,BookingDate")] Booking booking)
        {
            if (id != booking.BookingId) return NotFound();

            if (ModelState.IsValid)
            {
                var selectedEvent = await _context.Events.FindAsync(booking.EventId);
                if (selectedEvent == null)
                {
                    ModelState.AddModelError("EventId", "Selected event not found.");
                    await PopulateDropDownsAsync(booking.EventId, booking.VenueId);
                    return View(booking);
                }

                // Double-booking check (exclude current booking)
                bool conflict = await _context.Bookings
                    .Include(b => b.Event)
                    .AnyAsync(b =>
                        b.BookingId != booking.BookingId &&
                        b.VenueId == booking.VenueId &&
                        b.Event != null &&
                        b.Event.EventDate.Date == selectedEvent.EventDate.Date);

                if (conflict)
                {
                    ModelState.AddModelError(string.Empty,
                        "This venue is already booked for another event on the same date.");
                    await PopulateDropDownsAsync(booking.EventId, booking.VenueId);
                    return View(booking);
                }

                try
                {
                    _context.Update(booking);
                    await _context.SaveChangesAsync();
                    TempData["Success"] = $"Booking #{booking.BookingId} updated successfully.";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_context.Bookings.Any(b => b.BookingId == booking.BookingId)) return NotFound();
                    throw;
                }
                return RedirectToAction(nameof(Index));
            }

            await PopulateDropDownsAsync(booking.EventId, booking.VenueId);
            return View(booking);
        }

        // GET: Bookings/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var booking = await _context.Bookings
                .Include(b => b.Event).ThenInclude(e => e!.EventType)
                .Include(b => b.Venue)
                .FirstOrDefaultAsync(b => b.BookingId == id);

            if (booking == null) return NotFound();
            return View(booking);
        }

        // POST: Bookings/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var booking = await _context.Bookings.FindAsync(id);
            if (booking == null) return NotFound();

            _context.Bookings.Remove(booking);
            await _context.SaveChangesAsync();
            TempData["Success"] = $"Booking #{id} deleted successfully.";
            return RedirectToAction(nameof(Index));
        }

        // ── Helpers ────────────────────────────────────────────────────────────
        private async Task PopulateDropDownsAsync(int? selectedEventId = null, int? selectedVenueId = null)
        {
            ViewBag.EventId = new SelectList(
                await _context.Events.Include(e => e.EventType)
                    .OrderBy(e => e.EventName).ToListAsync(),
                "EventId", "EventName", selectedEventId);

            ViewBag.VenueId = new SelectList(
                await _context.Venues.OrderBy(v => v.VenueName).ToListAsync(),
                "VenueId", "VenueName", selectedVenueId);
        }
    }
}
