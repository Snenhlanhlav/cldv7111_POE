using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventEase.Data;

namespace EventEase.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            ViewBag.VenueCount = await _context.Venues.CountAsync();
            ViewBag.EventCount = await _context.Events.CountAsync();
            ViewBag.BookingCount = await _context.Bookings.CountAsync();
            ViewBag.AvailableVenueCount = await _context.Venues.CountAsync(v => v.IsAvailable);

            var upcoming = await _context.Events
                .Include(e => e.Venue)
                .Include(e => e.EventType)
                .Where(e => e.EventDate >= DateTime.Today)
                .OrderBy(e => e.EventDate)
                .Take(5)
                .ToListAsync();

            ViewBag.UpcomingEvents = upcoming;

            return View();
        }
    }
}
