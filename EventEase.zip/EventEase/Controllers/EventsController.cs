using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using EventEase.Data;
using EventEase.Models;
using EventEase.Services;

namespace EventEase.Controllers
{
    public class EventsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IBlobStorageService _blobService;
        private const string ContainerName = "event-images";

        public EventsController(ApplicationDbContext context, IBlobStorageService blobService)
        {
            _context = context;
            _blobService = blobService;
        }

        // GET: Events
        public async Task<IActionResult> Index(string? searchTerm, int? eventTypeId, DateTime? fromDate, DateTime? toDate)
        {
            var query = _context.Events
                .Include(e => e.Venue)
                .Include(e => e.EventType)
                .AsQueryable();

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                var s = searchTerm.Trim().ToLower();
                query = query.Where(e => e.EventName.ToLower().Contains(s) ||
                                         (e.Description != null && e.Description.ToLower().Contains(s)));
            }

            if (eventTypeId.HasValue)
                query = query.Where(e => e.EventTypeId == eventTypeId);

            if (fromDate.HasValue)
                query = query.Where(e => e.EventDate >= fromDate.Value);

            if (toDate.HasValue)
                query = query.Where(e => e.EventDate <= toDate.Value.AddDays(1));

            ViewBag.SearchTerm = searchTerm;
            ViewBag.SelectedEventTypeId = eventTypeId;
            ViewBag.FromDate = fromDate?.ToString("yyyy-MM-dd");
            ViewBag.ToDate = toDate?.ToString("yyyy-MM-dd");
            ViewBag.EventTypes = new SelectList(await _context.EventTypes.OrderBy(et => et.TypeName).ToListAsync(),
                "EventTypeId", "TypeName", eventTypeId);

            return View(await query.OrderBy(e => e.EventDate).ToListAsync());
        }

        // GET: Events/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var ev = await _context.Events
                .Include(e => e.Venue)
                .Include(e => e.EventType)
                .Include(e => e.Bookings)
                .FirstOrDefaultAsync(e => e.EventId == id);

            if (ev == null) return NotFound();
            return View(ev);
        }

        // GET: Events/Create
        public async Task<IActionResult> Create()
        {
            await PopulateDropDownsAsync();
            return View();
        }

        // POST: Events/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(
            [Bind("EventName,EventDate,EndDate,Description,VenueId,EventTypeId")] Event ev,
            IFormFile? imageFile, string? imageUrl)
        {
            if (ModelState.IsValid)
            {
                if (imageFile != null && imageFile.Length > 0)
                    ev.ImageUrl = await _blobService.UploadImageAsync(imageFile, ContainerName);
                else if (!string.IsNullOrWhiteSpace(imageUrl))
                    ev.ImageUrl = imageUrl;

                _context.Events.Add(ev);
                await _context.SaveChangesAsync();
                TempData["Success"] = $"Event '{ev.EventName}' created successfully.";
                return RedirectToAction(nameof(Index));
            }

            await PopulateDropDownsAsync(ev.VenueId, ev.EventTypeId);
            return View(ev);
        }

        // GET: Events/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();
            var ev = await _context.Events.FindAsync(id);
            if (ev == null) return NotFound();

            await PopulateDropDownsAsync(ev.VenueId, ev.EventTypeId);
            return View(ev);
        }

        // POST: Events/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id,
            [Bind("EventId,EventName,EventDate,EndDate,Description,VenueId,EventTypeId,ImageUrl")] Event ev,
            IFormFile? imageFile, string? imageUrl)
        {
            if (id != ev.EventId) return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    if (imageFile != null && imageFile.Length > 0)
                    {
                        if (!string.IsNullOrWhiteSpace(ev.ImageUrl))
                            await _blobService.DeleteImageAsync(ev.ImageUrl, ContainerName);
                        ev.ImageUrl = await _blobService.UploadImageAsync(imageFile, ContainerName);
                    }
                    else if (!string.IsNullOrWhiteSpace(imageUrl))
                    {
                        ev.ImageUrl = imageUrl;
                    }

                    _context.Update(ev);
                    await _context.SaveChangesAsync();
                    TempData["Success"] = $"Event '{ev.EventName}' updated successfully.";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_context.Events.Any(e => e.EventId == ev.EventId)) return NotFound();
                    throw;
                }
                return RedirectToAction(nameof(Index));
            }

            await PopulateDropDownsAsync(ev.VenueId, ev.EventTypeId);
            return View(ev);
        }

        // GET: Events/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var ev = await _context.Events
                .Include(e => e.Venue)
                .Include(e => e.EventType)
                .Include(e => e.Bookings)
                .FirstOrDefaultAsync(e => e.EventId == id);

            if (ev == null) return NotFound();

            ViewBag.HasBookings = ev.Bookings.Any();
            return View(ev);
        }

        // POST: Events/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var ev = await _context.Events
                .Include(e => e.Bookings)
                .FirstOrDefaultAsync(e => e.EventId == id);

            if (ev == null) return NotFound();

            if (ev.Bookings.Any())
            {
                TempData["Error"] = $"Cannot delete '{ev.EventName}' — it has {ev.Bookings.Count} existing booking(s). Remove the bookings first.";
                return RedirectToAction(nameof(Index));
            }

            if (!string.IsNullOrWhiteSpace(ev.ImageUrl))
                await _blobService.DeleteImageAsync(ev.ImageUrl, ContainerName);

            _context.Events.Remove(ev);
            await _context.SaveChangesAsync();
            TempData["Success"] = $"Event '{ev.EventName}' deleted successfully.";
            return RedirectToAction(nameof(Index));
        }

        // ── Helpers ────────────────────────────────────────────────────────────
        private async Task PopulateDropDownsAsync(int? selectedVenueId = null, int? selectedEventTypeId = null)
        {
            ViewBag.VenueId = new SelectList(
                await _context.Venues.Where(v => v.IsAvailable).OrderBy(v => v.VenueName).ToListAsync(),
                "VenueId", "VenueName", selectedVenueId);

            ViewBag.EventTypeId = new SelectList(
                await _context.EventTypes.OrderBy(et => et.TypeName).ToListAsync(),
                "EventTypeId", "TypeName", selectedEventTypeId);
        }
    }
}
