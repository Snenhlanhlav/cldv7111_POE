using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventEase.Data;
using EventEase.Models;
using EventEase.Services;

namespace EventEase.Controllers
{
    public class VenuesController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IBlobStorageService _blobService;
        private const string ContainerName = "venue-images";

        public VenuesController(ApplicationDbContext context, IBlobStorageService blobService)
        {
            _context = context;
            _blobService = blobService;
        }

        // GET: Venues
        public async Task<IActionResult> Index(string? searchTerm, bool? availableOnly)
        {
            var query = _context.Venues.AsQueryable();

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                searchTerm = searchTerm.Trim().ToLower();
                query = query.Where(v =>
                    v.VenueName.ToLower().Contains(searchTerm) ||
                    v.Location.ToLower().Contains(searchTerm));
            }

            if (availableOnly == true)
                query = query.Where(v => v.IsAvailable);

            ViewBag.SearchTerm = searchTerm;
            ViewBag.AvailableOnly = availableOnly;

            return View(await query.OrderBy(v => v.VenueName).ToListAsync());
        }

        // GET: Venues/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var venue = await _context.Venues
                .Include(v => v.Events)
                    .ThenInclude(e => e.EventType)
                .Include(v => v.Bookings)
                .FirstOrDefaultAsync(v => v.VenueId == id);

            if (venue == null) return NotFound();

            return View(venue);
        }

        // GET: Venues/Create
        public IActionResult Create() => View();

        // POST: Venues/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("VenueName,Location,Capacity,IsAvailable")] Venue venue,
            IFormFile? imageFile, string? imageUrl)
        {
            if (ModelState.IsValid)
            {
                if (imageFile != null && imageFile.Length > 0)
                    venue.ImageUrl = await _blobService.UploadImageAsync(imageFile, ContainerName);
                else if (!string.IsNullOrWhiteSpace(imageUrl))
                    venue.ImageUrl = imageUrl;

                _context.Venues.Add(venue);
                await _context.SaveChangesAsync();
                TempData["Success"] = $"Venue '{venue.VenueName}' created successfully.";
                return RedirectToAction(nameof(Index));
            }
            return View(venue);
        }

        // GET: Venues/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();
            var venue = await _context.Venues.FindAsync(id);
            if (venue == null) return NotFound();
            return View(venue);
        }

        // POST: Venues/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id,
            [Bind("VenueId,VenueName,Location,Capacity,ImageUrl,IsAvailable")] Venue venue,
            IFormFile? imageFile, string? imageUrl)
        {
            if (id != venue.VenueId) return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    if (imageFile != null && imageFile.Length > 0)
                    {
                        // Delete old blob if it was a blob URL
                        if (!string.IsNullOrWhiteSpace(venue.ImageUrl))
                            await _blobService.DeleteImageAsync(venue.ImageUrl, ContainerName);

                        venue.ImageUrl = await _blobService.UploadImageAsync(imageFile, ContainerName);
                    }
                    else if (!string.IsNullOrWhiteSpace(imageUrl))
                    {
                        venue.ImageUrl = imageUrl;
                    }

                    _context.Update(venue);
                    await _context.SaveChangesAsync();
                    TempData["Success"] = $"Venue '{venue.VenueName}' updated successfully.";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_context.Venues.Any(v => v.VenueId == venue.VenueId))
                        return NotFound();
                    throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(venue);
        }

        // GET: Venues/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var venue = await _context.Venues
                .Include(v => v.Bookings)
                .FirstOrDefaultAsync(v => v.VenueId == id);

            if (venue == null) return NotFound();

            ViewBag.HasBookings = venue.Bookings.Any();
            return View(venue);
        }

        // POST: Venues/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var venue = await _context.Venues
                .Include(v => v.Bookings)
                .FirstOrDefaultAsync(v => v.VenueId == id);

            if (venue == null) return NotFound();

            if (venue.Bookings.Any())
            {
                TempData["Error"] = $"Cannot delete '{venue.VenueName}' — it has {venue.Bookings.Count} existing booking(s). Remove the bookings first.";
                return RedirectToAction(nameof(Index));
            }

            if (!string.IsNullOrWhiteSpace(venue.ImageUrl))
                await _blobService.DeleteImageAsync(venue.ImageUrl, ContainerName);

            _context.Venues.Remove(venue);
            await _context.SaveChangesAsync();
            TempData["Success"] = $"Venue '{venue.VenueName}' deleted successfully.";
            return RedirectToAction(nameof(Index));
        }
    }
}
