namespace EventEase.Models
{
    /// <summary>
    /// View model representing consolidated booking information
    /// (maps to the vw_BookingDetails database view)
    /// </summary>
    public class BookingDetail
    {
        public int BookingId { get; set; }
        public DateTime BookingDate { get; set; }
        public string EventName { get; set; } = string.Empty;
        public DateTime EventDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string? EventDescription { get; set; }
        public string? EventTypeName { get; set; }
        public string VenueName { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;
        public int Capacity { get; set; }
        public string? VenueImageUrl { get; set; }
        public string? EventImageUrl { get; set; }
    }
}
