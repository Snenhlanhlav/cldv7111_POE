using System.ComponentModel.DataAnnotations;

namespace EventEase.Models
{
    public class EventType
    {
        public int EventTypeId { get; set; }

        [Required(ErrorMessage = "Event type name is required.")]
        [StringLength(100)]
        [Display(Name = "Event Type")]
        public string TypeName { get; set; } = string.Empty;

        // Navigation
        public ICollection<Event> Events { get; set; } = new List<Event>();
    }
}
